package mundo.interfac;

public interface IDevolucion {

	public void hacerDevolucion(); //M�todo Abstracto
	
	
	
}
